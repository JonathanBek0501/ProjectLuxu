<template>
    <footer class="flex relative max-w-xxl w-full mx-auto lg:px-3">
        <div class="lg:w-[67px]"></div>
        <div class="w-full lg:bg-white/20 lg:backdrop-blur-md lg:px-1">
            <div class="flex flex-wrap items-center bg-black font-bold text-brand-gray-100 gap-10 lg:gap-20 border-t border-brand-black-100 py-8 px-5 lg:px-14">
                <a href="#">Servermetin.net</a>
                <a href="#">metinservers.com</a>
                <a href="#">votemetin.com</a>
                <div href="#" class="flex items-center ml-auto">
                    <a href="#">UI/UX Design:</a>
                    <a href="#" class="text-brand-gray-50">Check Profile</a>
                </div>
            </div>
        </div>
    </footer>
</template>